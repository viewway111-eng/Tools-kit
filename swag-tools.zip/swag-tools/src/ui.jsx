import { useEffect, useState } from 'react'
export const copy = async (t, set) => { try { await navigator.clipboard.writeText(t); set?.('Copied') } catch { set?.('Copy failed. Select the text and copy manually.') } }
export function download(name, text, type = 'text/plain') {
  const u = URL.createObjectURL(new Blob([text], { type })), a = document.createElement('a')
  a.href = u; a.download = name; a.click(); URL.revokeObjectURL(u)
}
export const TA = ({ v, s, ph, rows = 8 }) => <textarea rows={rows} value={v} onChange={e => s(e.target.value)} placeholder={ph} aria-label={ph || 'Text'} />
export const L = ({ t, children }) => <label>{t}{children}</label>
export const Err = ({ e }) => e ? <p className="err" role="alert">{e}</p> : null
export function Out({ value, name = 'result.txt', rows = 8 }) {
  const [m, setM] = useState('')
  return <div><textarea readOnly rows={rows} value={value} aria-label="Result" />
    <div className="row"><button onClick={() => copy(value, setM)} disabled={!value}>Copy</button><button onClick={() => download(name, value)} disabled={!value}>Download</button><span role="status">{m}</span></div></div>
}
export function useSeo(title, desc) {
  useEffect(() => {
    document.title = title
    let m = document.querySelector('meta[name=description]')
    if (!m) { m = document.createElement('meta'); m.name = 'description'; document.head.appendChild(m) }
    m.content = desc
  }, [title, desc])
}
