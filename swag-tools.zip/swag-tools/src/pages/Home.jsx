import { useState } from 'react'
import { Link } from 'react-router-dom'
import { TOOLS, CATS } from '../tools/registry.jsx'
import { usePrefs } from '../store.jsx'
import { useSeo } from '../ui.jsx'
function Card({ t }) {
  const { favs, toggleFav } = usePrefs(), fav = favs.includes(t.slug)
  return <li className="tcard"><Link to={'/tool/' + t.slug}><b>{t.name}</b><span>{t.desc}</span></Link>
    <button aria-pressed={fav} aria-label={(fav ? 'Remove ' : 'Add ') + t.name + ' favourite'} onClick={() => toggleFav(t.slug)}>{fav ? '★' : '☆'}</button></li>
}
export default function Home() {
  const [q, setQ] = useState(''), [cat, setCat] = useState('all'), { favs, recent } = usePrefs()
  useSeo('SWAG Tools - Free online image, text, SEO, developer and color tools', 'Free online tools that run in your browser: image resizer, compressor, text tools, SEO generators, JSON formatter, color tools, password generator and more.')
  const s = q.trim().toLowerCase(), list = TOOLS.filter(t => (cat === 'all' || t.cat === cat) && (!s || t.name.toLowerCase().includes(s)))
  const by = a => a.map(x => TOOLS.find(t => t.slug === x)).filter(Boolean)
  return <>
    <section className="hero"><div className="wrap"><h1>Free online tools that run in your browser</h1>
      <p>Your files and text stay on your device.</p>
      <input type="search" value={q} onChange={e => { setQ(e.target.value); setCat('all') }} placeholder="Search tools by name" aria-label="Search tools by name" /></div></section>
    <div className="wrap">
      {!s && <><h2>Categories</h2><div className="cats">{Object.entries(CATS).map(([k, c]) => { const n = TOOLS.filter(t => t.cat === k).length; return n ? <button key={k} className={'catcard' + (cat === k ? ' on' : '')} aria-pressed={cat === k} onClick={() => setCat(cat === k ? 'all' : k)}><span aria-hidden>{c.icon}</span><b>{c.name}</b><small>{n} tools</small></button> : null })}</div></>}
      {!s && cat === 'all' && recent.length > 0 && <><h2>Recently used</h2><ul className="tgrid">{by(recent).map(t => <Card key={t.slug} t={t} />)}</ul></>}
      {!s && cat === 'all' && favs.length > 0 && <><h2>Favourites</h2><ul className="tgrid">{by(favs).map(t => <Card key={t.slug} t={t} />)}</ul></>}
      <h2>{s ? 'Search results' : cat === 'all' ? 'All tools' : CATS[cat].name}</h2>
      {list.length ? <ul className="tgrid">{list.map(t => <Card key={t.slug} t={t} />)}</ul> : <p>No tool matches "{q}".</p>}
    </div></>
}
