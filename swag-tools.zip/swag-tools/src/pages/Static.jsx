import { useParams, Link } from 'react-router-dom'
import { CONTACT_EMAIL, SITE_NAME } from '../config.js'
import { useSeo } from '../ui.jsx'
const P = {
  about: ['About Us', <><p>{SITE_NAME} is a collection of free online tools. Most tools run entirely in your browser, so your text and files are not sent to a server.</p><p>We add tools gradually and only list tools that work.</p></>],
  contact: ['Contact Us', CONTACT_EMAIL ? <p>Email us at <a href={'mailto:' + CONTACT_EMAIL}>{CONTACT_EMAIL}</a>.</p> : <p>The site owner has not set a contact email yet. Edit <code>CONTACT_EMAIL</code> in <code>src/config.js</code> before launch.</p>],
  privacy: ['Privacy Policy', <><p>Tools process your input locally in your browser. We do not upload your files or text to our servers.</p><p>We store your theme, favourite tools and recently used tools in your browser's local storage. They never leave your device and you can clear them in your browser settings.</p><p>If advertising or analytics are added later, this policy must be updated to describe cookies and data collected by those services.</p></>],
  terms: ['Terms of Use', <><p>The tools are provided as they are, free of charge, without warranties. You are responsible for how you use the results and for having the right to process any files you use.</p><p>We may change or remove tools at any time.</p></>],
  disclaimer: ['Disclaimer', <><p>Results are for general use and may contain errors. Check important results before relying on them (for example SEO files, converted units, or generated code).</p><p>Tools that mention AI only explain what needs an API. This site does not claim to use an AI service unless one is configured.</p></>]
}
export function Page() {
  const { p } = useParams(), d = P[p]
  useSeo(d ? d[0] + ' - ' + SITE_NAME : 'Not found', d ? d[0] + ' for ' + SITE_NAME : 'Page not found')
  return <section className="wrap narrow"><h1>{d ? d[0] : 'Page not found'}</h1>{d ? d[1] : <Link to="/">Back to home</Link>}</section>
}
