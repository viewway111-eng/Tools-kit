import { useEffect } from 'react'
import { useParams, Link } from 'react-router-dom'
import { TOOLS, CATS } from '../tools/registry.jsx'
import { usePrefs } from '../store.jsx'
import { useSeo } from '../ui.jsx'
export default function Tool() {
  const { slug } = useParams(), t = TOOLS.find(x => x.slug === slug), { favs, toggleFav, addRecent } = usePrefs()
  useSeo(t ? t.name + ' - Free Online Tool | SWAG Tools' : 'Tool not found', t ? t.desc : 'Tool not found')
  useEffect(() => { if (t) addRecent(t.slug) }, [slug]) // eslint-disable-line
  if (!t) return <section className="wrap"><h1>Tool not found</h1><Link to="/">Back to all tools</Link></section>
  const C = t.C, fav = favs.includes(t.slug)
  return <article className="wrap">
    <p className="crumb"><Link to="/">Home</Link> / {CATS[t.cat].name}</p>
    <div className="row between"><h1>{t.name}</h1><button aria-pressed={fav} onClick={() => toggleFav(t.slug)}>{fav ? '★ Favourite' : '☆ Add to favourites'}</button></div>
    <p className="mu">{t.desc}</p>
    <section className="panel" aria-label={t.name}><C /></section>
    <section><h2>How to use</h2><p>{t.how}</p><h2>Example</h2><p>{t.ex}</p></section>
  </article>
}
