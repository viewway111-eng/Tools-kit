import { createContext, useContext, useEffect, useState } from 'react'
const P = createContext({})
export const usePrefs = () => useContext(P)
function useLocal(k, init) {
  const [v, setV] = useState(() => { try { return JSON.parse(localStorage.getItem(k)) ?? init } catch { return init } })
  useEffect(() => { try { localStorage.setItem(k, JSON.stringify(v)) } catch { /* storage unavailable */ } }, [k, v])
  return [v, setV]
}
export function PrefsProvider({ children }) {
  const [theme, setTheme] = useLocal('swag-theme', window.matchMedia?.('(prefers-color-scheme: light)').matches ? 'light' : 'dark')
  const [favs, setFavs] = useLocal('swag-favs', []), [recent, setRecent] = useLocal('swag-recent', [])
  useEffect(() => { document.documentElement.dataset.theme = theme }, [theme])
  const toggleFav = s => setFavs(f => f.includes(s) ? f.filter(x => x !== s) : [...f, s])
  const addRecent = s => setRecent(r => [s, ...r.filter(x => x !== s)].slice(0, 6))
  return <P.Provider value={{ theme, setTheme, favs, recent, toggleFav, addRecent }}>{children}</P.Provider>
}
