// Set your real public contact email before launch. Leave empty to show a "not configured" notice instead of a fake address.
export const CONTACT_EMAIL = ''
export const SITE_NAME = 'SWAG Tools'
