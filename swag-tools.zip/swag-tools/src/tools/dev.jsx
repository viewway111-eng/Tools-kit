import { useState } from 'react'
import { TA, Out, L, Err, download } from '../ui.jsx'

export function Json() {
  const [t, s] = useState(''), [o, setO] = useState(''), [e, setE] = useState(''), [ok, setOk] = useState(''), [ind, setInd] = useState(2)
  function run(m) {
    setE(''); setO(''); setOk(''); if (!t.trim()) return setE('Paste some JSON first.')
    try { const v = JSON.parse(t); if (m === 'val') setOk('Valid JSON'); else setO(m === 'min' ? JSON.stringify(v) : JSON.stringify(v, null, ind)) } catch (x) { setE('Invalid JSON: ' + x.message) }
  }
  return <><TA v={t} s={s} ph='Paste JSON, e.g. {"name":"SWAG"}' rows={8} /><L t="Indent"><select value={ind} onChange={e => setInd(+e.target.value)}><option value={2}>2 spaces</option><option value={4}>4 spaces</option></select></L>
    <button className="on" onClick={() => run('fmt')}>Format</button><button onClick={() => run('min')}>Minify</button><button onClick={() => run('val')}>Validate</button><button onClick={() => { s(''); setO(''); setE(''); setOk('') }}>Reset</button>
    <Err e={e} />{ok && <p className="ok" role="status">{ok}</p>}{o && <Out value={o} name="data.json" rows={10} />}</>
}

export function Url() {
  const [t, s] = useState(''), [o, setO] = useState(''), [e, setE] = useState('')
  function run(f) { setE(''); try { setO(f(t)) } catch { setO(''); setE('Could not decode: the text has an invalid % sequence.') } }
  return <><TA v={t} s={s} ph="Text or URL part" rows={4} /><button className="on" onClick={() => run(encodeURIComponent)}>Encode</button><button onClick={() => run(decodeURIComponent)}>Decode</button><button onClick={() => { s(''); setO(''); setE('') }}>Reset</button><Err e={e} /><Out value={o} name="url.txt" rows={4} /></>
}

const enc = t => { let r = ''; new TextEncoder().encode(t).forEach(x => r += String.fromCharCode(x)); return btoa(r) }
const dec = t => new TextDecoder('utf-8', { fatal: true }).decode(Uint8Array.from(atob(t.replace(/\s/g, '')), c => c.charCodeAt(0)))
export function B64() {
  const [t, s] = useState(''), [o, setO] = useState(''), [e, setE] = useState('')
  function run(f) { setE(''); if (!t) { setO(''); return setE('Enter some text first.') } try { setO(f(t)) } catch { setO(''); setE('Invalid input for this operation (not valid Base64 / UTF-8 text).') } }
  return <><TA v={t} s={s} ph="Text or Base64" rows={5} /><button className="on" onClick={() => run(enc)}>Encode</button><button onClick={() => run(dec)}>Decode</button><button onClick={() => { s(''); setO(''); setE('') }}>Reset</button><Err e={e} /><Out value={o} name="base64.txt" rows={5} /></>
}

const SAMPLE = '<h1>Hello from SWAG Tools</h1>\n<p>Edit this HTML and press Run.</p>\n<style>h1{color:#7c5cff}</style>'
export function Preview() {
  const [t, s] = useState(SAMPLE), [src, setSrc] = useState(SAMPLE)
  return <><TA v={t} s={s} ph="HTML, CSS and JavaScript" rows={9} /><button className="on" onClick={() => setSrc(t)}>Run</button><button onClick={() => download('page.html', t, 'text/html')}>Download HTML</button><button onClick={() => { s(''); setSrc('') }}>Reset</button>
    <p className="mu">The preview runs in a sandboxed iframe without access to this site, its storage or your cookies.</p><iframe title="Preview" sandbox="allow-scripts" srcDoc={src} /></>
}
