import { useState } from 'react'
import { L, Err, copy } from '../ui.jsx'
const hex2rgb = h => { h = h.trim().replace(/^#/, ''); if (/^[0-9a-f]{3}$/i.test(h)) h = [...h].map(c => c + c).join(''); return /^[0-9a-f]{6}$/i.test(h) ? [0, 2, 4].map(i => parseInt(h.slice(i, i + 2), 16)) : null }
const rgb2hex = (r, g, b) => '#' + [r, g, b].map(v => v.toString(16).padStart(2, '0')).join('')
const rgb2hsl = (r, g, b) => { r /= 255; g /= 255; b /= 255; const M = Math.max(r, g, b), m = Math.min(r, g, b), l = (M + m) / 2; let h = 0, s = 0; if (M !== m) { const d = M - m; s = l > .5 ? d / (2 - M - m) : d / (M + m); h = M === r ? (g - b) / d + (g < b ? 6 : 0) : M === g ? (b - r) / d + 2 : (r - g) / d + 4; h *= 60 } return [Math.round(h), Math.round(s * 100), Math.round(l * 100)] }
const hsl2hex = (h, s, l) => { h = ((h % 360) + 360) % 360; s /= 100; l /= 100; const a = s * Math.min(l, 1 - l), f = n => { const k = (n + h / 30) % 12; return l - a * Math.max(-1, Math.min(k - 3, 9 - k, 1)) }; return rgb2hex(...[f(0), f(8), f(4)].map(x => Math.round(x * 255))) }
function Val({ label, v }) { const [m, setM] = useState(''); return <div className="row"><b>{label}:</b> <code>{v}</code><button onClick={() => copy(v, setM)}>Copy</button><span role="status">{m}</span></div> }

export function Picker() {
  const [c, setC] = useState('#7c5cff'), [r, g, b] = hex2rgb(c), [h, s, l] = rgb2hsl(r, g, b)
  return <><L t="Pick a color"><input type="color" value={c} onChange={e => setC(e.target.value)} /></L><Val label="HEX" v={c.toUpperCase()} /><Val label="RGB" v={`rgb(${r}, ${g}, ${b})`} /><Val label="HSL" v={`hsl(${h}, ${s}%, ${l}%)`} /></>
}
export function HexRgb() {
  const [t, s] = useState(''), v = t.trim() ? hex2rgb(t) : null
  return <><L t="HEX color (3 or 6 digits, # optional)"><input value={t} onChange={e => s(e.target.value)} placeholder="#7c5cff" /></L>{t.trim() && !v && <Err e="Enter a valid HEX color such as #7c5cff or 7cf." />}
    {v && <><div className="sw" style={{ background: `rgb(${v})` }} /><Val label="RGB" v={`rgb(${v.join(', ')})`} /></>}<button onClick={() => s('')}>Reset</button></>
}
export function RgbHex() {
  const [v, setV] = useState(['', '', '']), n = v.map(x => (x === '' ? NaN : Number(x))), ok = n.every(x => Number.isInteger(x) && x >= 0 && x <= 255), any = v.some(x => x !== '')
  return <div><div className="row">{['R', 'G', 'B'].map((k, i) => <L key={k} t={k + ' (0-255)'}><input type="number" min="0" max="255" value={v[i]} onChange={e => setV(v.map((x, j) => j === i ? e.target.value : x))} /></L>)}</div>
    {any && !ok && <Err e="Each value must be a whole number from 0 to 255." />}{ok && <><div className="sw" style={{ background: `rgb(${n})` }} /><Val label="HEX" v={rgb2hex(...n).toUpperCase()} /></>}<button onClick={() => setV(['', '', ''])}>Reset</button></div>
}
export function Palette() {
  const [c, setC] = useState('#7c5cff'), [r, g, b] = hex2rgb(c), [h, s, l] = rgb2hsl(r, g, b), [m, setM] = useState('')
  const sets = { Complementary: [h, h + 180], Analogous: [h - 30, h, h + 30], Triadic: [h, h + 120, h + 240], 'Split complementary': [h, h + 150, h + 210] }
  const rows = [...Object.entries(sets).map(([k, a]) => [k, a.map(x => hsl2hex(x, s, l))]), ['Shades', [15, 30, 45, 60, 75, 90].map(x => hsl2hex(h, s, x))]]
  return <><L t="Base color"><input type="color" value={c} onChange={e => setC(e.target.value)} /></L><p role="status" className="mu">{m || 'Click a swatch to copy its HEX code.'}</p>
    {rows.map(([k, a]) => <div key={k}><h3>{k}</h3><div className="swg">{a.map(x => <button key={x} className="sw" style={{ background: x }} onClick={() => copy(x, () => setM('Copied ' + x))}>{x.toUpperCase()}</button>)}</div></div>)}</>
}
