import { useState } from 'react'
import { TA, Out, L, Err } from '../ui.jsx'
const esc = s => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;')
const isUrl = u => { try { return /^https?:$/.test(new URL(u).protocol) } catch { return false } }

export function Slug() {
  const [t, s] = useState('')
  const slug = t.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/&/g, ' and ').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '')
  return <><TA v={t} s={s} ph="Enter a title, e.g. 10 Tips for Faster Websites!" rows={3} /><Out value={slug} name="slug.txt" rows={2} /><button onClick={() => s('')}>Reset</button></>
}

export function Meta() {
  const [f, setF] = useState({ title: '', desc: '', url: '', robots: 'index, follow', img: '' }), [out, setOut] = useState(''), [e, setE] = useState([])
  const set = (k, v) => setF({ ...f, [k]: v })
  function gen() {
    const er = []
    if (!f.title.trim()) er.push('Title is required.'); if (!f.desc.trim()) er.push('Description is required.')
    if (f.url && !isUrl(f.url)) er.push('Canonical URL must start with http:// or https://.'); if (f.img && !isUrl(f.img)) er.push('Image URL must start with http:// or https://.')
    setE(er); if (er.length) return setOut('')
    const T = esc(f.title.trim()), D = esc(f.desc.trim())
    setOut(['<title>' + T + '</title>', `<meta name="description" content="${D}">`, `<meta name="robots" content="${f.robots}">`, f.url && `<link rel="canonical" href="${esc(f.url)}">`, `<meta property="og:title" content="${T}">`, `<meta property="og:description" content="${D}">`, `<meta property="og:type" content="website">`, f.url && `<meta property="og:url" content="${esc(f.url)}">`, f.img && `<meta property="og:image" content="${esc(f.img)}">`, `<meta name="twitter:card" content="${f.img ? 'summary_large_image' : 'summary'}">`].filter(Boolean).join('\n'))
  }
  return <><L t="Page title"><input value={f.title} onChange={e => set('title', e.target.value)} /></L><p className="mu">{f.title.length} characters (about 60 or fewer is usually shown in full)</p>
    <L t="Meta description"><textarea rows={3} value={f.desc} onChange={e => set('desc', e.target.value)} /></L><p className="mu">{f.desc.length} characters (about 160 or fewer is usually shown in full)</p>
    <L t="Canonical URL (optional)"><input value={f.url} onChange={e => set('url', e.target.value)} placeholder="https://example.com/page" /></L>
    <L t="Social image URL (optional)"><input value={f.img} onChange={e => set('img', e.target.value)} placeholder="https://example.com/image.jpg" /></L>
    <L t="Robots"><select value={f.robots} onChange={e => set('robots', e.target.value)}><option>index, follow</option><option>noindex, follow</option><option>noindex, nofollow</option></select></L>
    {e.map(x => <Err key={x} e={x} />)}<button className="on" onClick={gen}>Generate tags</button><Out value={out} name="meta-tags.html" /></>
}

export function Robots() {
  const [ua, setUa] = useState('*'), [al, setAl] = useState(''), [dis, setDis] = useState('/admin/'), [sm, setSm] = useState(''), [out, setOut] = useState(''), [e, setE] = useState('')
  function gen() {
    const A = al.split('\n').map(x => x.trim()).filter(Boolean), D = dis.split('\n').map(x => x.trim()).filter(Boolean)
    if (!ua.trim()) return setE('User-agent is required.'); if ([...A, ...D].some(p => !p.startsWith('/'))) return setE('Every path must start with /.')
    if (sm && !isUrl(sm)) return setE('Sitemap must be a full http(s) URL.'); setE('')
    const l = ['User-agent: ' + ua.trim(), ...A.map(p => 'Allow: ' + p), ...(D.length ? D.map(p => 'Disallow: ' + p) : ['Disallow:'])]; if (sm) l.push('', 'Sitemap: ' + sm); setOut(l.join('\n') + '\n')
  }
  return <><L t="User-agent"><input value={ua} onChange={e => setUa(e.target.value)} /></L><L t="Allow paths (one per line)"><textarea rows={3} value={al} onChange={e => setAl(e.target.value)} placeholder="/public/" /></L>
    <L t="Disallow paths (one per line, empty = allow all)"><textarea rows={3} value={dis} onChange={e => setDis(e.target.value)} /></L><L t="Sitemap URL (optional)"><input value={sm} onChange={e => setSm(e.target.value)} placeholder="https://example.com/sitemap.xml" /></L>
    <Err e={e} /><button className="on" onClick={gen}>Generate robots.txt</button><Out value={out} name="robots.txt" /></>
}

export function Sitemap() {
  const [t, s] = useState(''), [cf, setCf] = useState(''), [lm, setLm] = useState(true), [out, setOut] = useState(''), [e, setE] = useState('')
  function gen() {
    const U = [...new Set(t.split('\n').map(x => x.trim()).filter(Boolean))]
    if (!U.length) return setE('Enter at least one URL.'); const bad = U.find(u => !isUrl(u)); if (bad) return setE('Invalid URL: ' + bad); if (U.length > 50000) return setE('Sitemaps are limited to 50,000 URLs.'); setE('')
    const d = new Date().toISOString().slice(0, 10)
    setOut('<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' + U.map(u => '  <url>\n    <loc>' + esc(u) + '</loc>\n' + (lm ? '    <lastmod>' + d + '</lastmod>\n' : '') + (cf ? '    <changefreq>' + cf + '</changefreq>\n' : '') + '  </url>').join('\n') + '\n</urlset>\n')
  }
  return <><TA v={t} s={s} ph="One full URL per line, e.g. https://example.com/" rows={6} /><L t="Change frequency (optional)"><select value={cf} onChange={e => setCf(e.target.value)}><option value="">Not set</option><option>daily</option><option>weekly</option><option>monthly</option><option>yearly</option></select></L>
    <label><input type="checkbox" checked={lm} onChange={e => setLm(e.target.checked)} />Add today's date as lastmod</label><Err e={e} /><button className="on" onClick={gen}>Generate sitemap.xml</button><Out value={out} name="sitemap.xml" rows={10} /></>
}
