import { useState } from 'react'
import { L, Err, Out } from '../ui.jsx'

const rnd = n => { const lim = Math.floor(2 ** 32 / n) * n, a = new Uint32Array(1); do crypto.getRandomValues(a); while (a[0] >= lim); return a[0] % n }
export function Password() {
  const [len, setLen] = useState(16), [o, setO] = useState({ lower: true, upper: true, digit: true, sym: true, amb: false }), [pw, setPw] = useState(''), [e, setE] = useState('')
  function gen() {
    const ex = o.amb ? /[O0oIl1]/g : null, S = { lower: 'abcdefghijklmnopqrstuvwxyz', upper: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', digit: '0123456789', sym: '!@#$%^&*()-_=+[]{};:,.?' }
    const sets = Object.keys(S).filter(k => o[k]).map(k => ex ? S[k].replace(ex, '') : S[k])
    if (!sets.length) return setE('Select at least one character type.'); if (!(len >= 8 && len <= 64)) return setE('Length must be between 8 and 64.'); setE('')
    const all = sets.join(''), c = sets.map(x => x[rnd(x.length)]); while (c.length < len) c.push(all[rnd(all.length)])
    for (let i = c.length - 1; i > 0; i--) { const j = rnd(i + 1);[c[i], c[j]] = [c[j], c[i]] } setPw(c.join(''))
  }
  const ck = (k, t) => <label><input type="checkbox" checked={o[k]} onChange={e => setO({ ...o, [k]: e.target.checked })} />{t}</label>
  return <><L t={'Length: ' + len}><input type="range" min="8" max="64" value={len} onChange={e => setLen(+e.target.value)} /></L>{ck('lower', 'Lowercase')}{ck('upper', 'Uppercase')}{ck('digit', 'Numbers')}{ck('sym', 'Symbols')}{ck('amb', 'Avoid look-alike characters (O, 0, l, 1, I)')}
    <Err e={e} /><button className="on" onClick={gen}>Generate password</button><Out value={pw} name="password.txt" rows={2} /><p className="mu">Generated with your browser's secure random generator. Nothing is sent anywhere.</p></>
}

const U = {
  Length: { m: 1, km: 1000, cm: .01, mm: .001, mi: 1609.344, yd: .9144, ft: .3048, in: .0254 },
  Mass: { kg: 1, g: .001, mg: 1e-6, lb: .45359237, oz: .028349523125 },
  Volume: { L: 1, mL: .001, 'gal (US)': 3.785411784, 'qt (US)': .946352946, 'cup (US)': .2365882365, 'fl oz (US)': .0295735295625 },
  Speed: { 'm/s': 1, 'km/h': 1 / 3.6, mph: .44704, knot: 1852 / 3600 },
  Temperature: { C: 1, F: 1, K: 1 } }
const toC = (v, u) => u === 'C' ? v : u === 'F' ? (v - 32) * 5 / 9 : v - 273.15
const fromC = (v, u) => u === 'C' ? v : u === 'F' ? v * 9 / 5 + 32 : v + 273.15
export function Units() {
  const [cat, setCat] = useState('Length'), [v, setV] = useState('1'), [a, setA] = useState('m'), [b, setB] = useState('ft')
  const keys = Object.keys(U[cat]), num = Number(v), bad = v.trim() === '' || !Number.isFinite(num)
  const res = bad ? null : cat === 'Temperature' ? fromC(toC(num, a), b) : num * U[cat][a] / U[cat][b]
  const pick = c => { setCat(c); const k = Object.keys(U[c]); setA(k[0]); setB(k[1] || k[0]) }
  return <><L t="Category"><select value={cat} onChange={e => pick(e.target.value)}>{Object.keys(U).map(k => <option key={k}>{k}</option>)}</select></L>
    <L t="Value"><input type="number" value={v} onChange={e => setV(e.target.value)} /></L>
    <div className="two"><L t="From"><select value={a} onChange={e => setA(e.target.value)}>{keys.map(k => <option key={k}>{k}</option>)}</select></L><L t="To"><select value={b} onChange={e => setB(e.target.value)}>{keys.map(k => <option key={k}>{k}</option>)}</select></L></div>
    {bad ? <Err e="Enter a valid number." /> : <p className="stats"><b role="status">{num} {a} = {Number(res.toPrecision(10))} {b}</b></p>}</>
}

const D = s => { const [y, m, d] = s.split('-').map(Number); return new Date(Date.UTC(y, m - 1, d)) }
const dim = (y, m) => new Date(Date.UTC(y, m + 1, 0)).getUTCDate()
const iso = d => d.toISOString().slice(0, 10)
function ymd(a, b) { let y = b.getUTCFullYear() - a.getUTCFullYear(), m = b.getUTCMonth() - a.getUTCMonth(), d = b.getUTCDate() - a.getUTCDate(); if (d < 0) { m--; d += dim(b.getUTCFullYear(), b.getUTCMonth() - 1) } if (m < 0) { y--; m += 12 } return [y, m, d] }
export function DateCalc() {
  const today = iso(new Date()), [mode, setMode] = useState('diff'), [d1, setD1] = useState(today), [d2, setD2] = useState(today), [n, setN] = useState(30), [unit, setUnit] = useState('days'), [sign, setSign] = useState(1)
  let out = null
  if (mode === 'diff' && d1 && d2) { let a = D(d1), b = D(d2); if (a > b)[a, b] = [b, a]; const days = Math.round((b - a) / 864e5), [y, m, d] = ymd(a, b); out = `${days} days (${Math.floor(days / 7)} weeks ${days % 7} days), or ${y} years ${m} months ${d} days` }
  if (mode === 'add' && d1 && Number.isInteger(n) && Math.abs(n) <= 100000) {
    const s = D(d1), k = sign * n
    if (unit === 'days' || unit === 'weeks') out = iso(new Date(s.getTime() + k * (unit === 'weeks' ? 7 : 1) * 864e5))
    else { const tm = s.getUTCMonth() + k * (unit === 'years' ? 12 : 1), y = s.getUTCFullYear() + Math.floor(tm / 12), m = ((tm % 12) + 12) % 12; out = iso(new Date(Date.UTC(y, m, Math.min(s.getUTCDate(), dim(y, m))))) }
  }
  return <><div className="row"><button className={mode === 'diff' ? 'on' : ''} onClick={() => setMode('diff')}>Difference between dates</button><button className={mode === 'add' ? 'on' : ''} onClick={() => setMode('add')}>Add or subtract time</button></div>
    <L t={mode === 'diff' ? 'Start date' : 'Date'}><input type="date" value={d1} onChange={e => setD1(e.target.value)} /></L>
    {mode === 'diff' ? <L t="End date"><input type="date" value={d2} onChange={e => setD2(e.target.value)} /></L> : <div className="two"><L t="Amount (whole number)"><input type="number" value={n} onChange={e => setN(e.target.value === '' ? NaN : +e.target.value)} /></L><L t="Unit"><select value={unit} onChange={e => setUnit(e.target.value)}><option>days</option><option>weeks</option><option>months</option><option>years</option></select></L>
      <label><input type="radio" checked={sign === 1} onChange={() => setSign(1)} />Add</label><label><input type="radio" checked={sign === -1} onChange={() => setSign(-1)} />Subtract</label></div>}
    {out ? <p className="stats"><b role="status">{out}</b></p> : <Err e="Enter valid dates and a whole-number amount." />}</>
}
