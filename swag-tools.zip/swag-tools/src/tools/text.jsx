import { useState } from 'react'
import { TA, Out, L, Err } from '../ui.jsx'

export function Words() {
  const [t, s] = useState('')
  const w = (t.match(/\S+/g) || []).length
  const sen = (t.match(/[^.!?]+[.!?]+|[^.!?]+$/g) || []).filter(x => x.trim()).length
  const p = t.split(/\n\s*\n/).filter(x => x.trim()).length
  const st = [['Words', w], ['Sentences', sen], ['Paragraphs', p], ['Reading time (200 wpm)', w ? Math.max(1, Math.ceil(w / 200)) + ' min' : '0 min']]
  return <><TA v={t} s={s} ph="Paste or type your text" /><dl className="stats">{st.map(([a, b]) => <div key={a}><dt>{a}</dt><dd>{b}</dd></div>)}</dl><button onClick={() => s('')}>Reset</button></>
}

export function Chars() {
  const [t, s] = useState(''), [lim, setLim] = useState(0)
  const n = [...t].length, ns = [...t.replace(/\s/g, '')].length
  return <><TA v={t} s={s} ph="Paste or type your text" />
    <L t="Character limit (optional)"><select value={lim} onChange={e => setLim(+e.target.value)}><option value={0}>No limit</option><option value={60}>60 (title tag)</option><option value={160}>160 (meta description)</option><option value={280}>280 (short post)</option></select></L>
    <dl className="stats">{[['Characters', n], ['Without spaces', ns], ['Lines', t ? t.split('\n').length : 0], ['Remaining', lim ? lim - n : '-']].map(([a, b]) => <div key={a}><dt>{a}</dt><dd>{b}</dd></div>)}</dl>
    {lim > 0 && n > lim && <p className="err">Over the limit by {n - lim} characters.</p>}<button onClick={() => s('')}>Reset</button></>
}

const wd = t => t.toLowerCase().match(/[\p{L}\p{N}]+/gu) || []
const CASES = {
  UPPERCASE: t => t.toUpperCase(), lowercase: t => t.toLowerCase(),
  'Title Case': t => t.toLowerCase().replace(/(^|\s)(\S)/g, (m, a, b) => a + b.toUpperCase()),
  'Sentence case': t => t.toLowerCase().replace(/(^\s*|[.!?]\s+)(\p{L})/gu, (m, a, b) => a + b.toUpperCase()),
  camelCase: t => wd(t).map((x, i) => i ? x[0].toUpperCase() + x.slice(1) : x).join(''),
  snake_case: t => wd(t).join('_'), 'kebab-case': t => wd(t).join('-') }
export function Case() {
  const [t, s] = useState(''), [m, setM] = useState('UPPERCASE')
  return <><TA v={t} s={s} ph="Type or paste text" rows={5} /><div className="row">{Object.keys(CASES).map(k => <button key={k} className={k === m ? 'on' : ''} onClick={() => setM(k)}>{k}</button>)}</div><Out value={t ? CASES[m](t) : ''} name="converted.txt" rows={5} /><button onClick={() => s('')}>Reset</button></>
}

export function Spaces() {
  const [t, s] = useState(''), [o, setO] = useState({ collapse: true, trim: true, blank: false })
  let r = t
  if (o.collapse) r = r.replace(/[ \t]+/g, ' ')
  if (o.trim) r = r.split('\n').map(x => x.trim()).join('\n').trim()
  if (o.blank) r = r.replace(/\n\s*\n+/g, '\n')
  const ck = (k, l) => <label><input type="checkbox" checked={o[k]} onChange={e => setO({ ...o, [k]: e.target.checked })} />{l}</label>
  return <><TA v={t} s={s} ph="Paste text with extra spaces" rows={6} />{ck('collapse', 'Collapse repeated spaces and tabs')}{ck('trim', 'Trim each line and the whole text')}{ck('blank', 'Remove blank lines')}<Out value={t ? r : ''} name="cleaned.txt" rows={6} /><button onClick={() => s('')}>Reset</button></>
}

function diff(a, b) {
  const n = a.length, m = b.length, D = Array.from({ length: n + 1 }, () => new Uint16Array(m + 1))
  for (let i = n - 1; i >= 0; i--) for (let j = m - 1; j >= 0; j--) D[i][j] = a[i] === b[j] ? D[i + 1][j + 1] + 1 : Math.max(D[i + 1][j], D[i][j + 1])
  const r = []; let i = 0, j = 0
  while (i < n && j < m) { if (a[i] === b[j]) { r.push(['=', a[i]]); i++; j++ } else if (D[i + 1][j] >= D[i][j + 1]) r.push(['-', a[i++]]); else r.push(['+', b[j++]]) }
  while (i < n) r.push(['-', a[i++]]); while (j < m) r.push(['+', b[j++]])
  return r
}
export function Diff() {
  const [a, sa] = useState(''), [b, sb] = useState(''), [r, setR] = useState(null), [e, setE] = useState('')
  function run() { const A = a.split('\n'), B = b.split('\n'); if (!a && !b) return setE('Enter text in at least one box.'); if (A.length > 1000 || B.length > 1000) return setE('Limit: 1000 lines per box.'); setE(''); setR(diff(A, B)) }
  const ch = r ? r.filter(x => x[0] !== '=').length : 0
  return <><div className="two"><div><b>Original</b><TA v={a} s={sa} ph="Original text" rows={8} /></div><div><b>Changed</b><TA v={b} s={sb} ph="Changed text" rows={8} /></div></div>
    <Err e={e} /><button className="on" onClick={run}>Compare</button><button onClick={() => { sa(''); sb(''); setR(null); setE('') }}>Reset</button>
    {r && <><p role="status">{ch ? ch + ' changed line(s). Green = added, red = removed.' : 'The texts are identical.'}</p><div className="diff panel">{r.map((x, i) => <div key={i} className={x[0] === '+' ? 'p' : x[0] === '-' ? 'm' : ''}>{x[0] === '=' ? '  ' : x[0] + ' '}{x[1]}</div>)}</div></>}</>
}

const LW = 'lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua enim ad minim veniam quis nostrud exercitation ullamco laboris nisi aliquip ex ea commodo consequat duis aute irure in reprehenderit voluptate velit esse cillum fugiat nulla pariatur excepteur sint occaecat cupidatat non proident sunt culpa qui officia deserunt mollit anim id est laborum'.split(' ')
export function Lorem() {
  const [n, setN] = useState(3), [out, setOut] = useState(''), [e, setE] = useState('')
  function gen() {
    if (!(n >= 1 && n <= 20)) return setE('Choose 1 to 20 paragraphs.'); setE('')
    let seed = 7; const r = k => (seed = (seed * 1103515245 + 12345) % 2147483648) % k
    const ps = Array.from({ length: n }, (_, p) => Array.from({ length: 4 + r(3) }, (_, i) => {
      const w = Array.from({ length: 8 + r(7) }, () => LW[r(LW.length)]); if (!p && !i) w.splice(0, 5, 'lorem', 'ipsum', 'dolor', 'sit', 'amet')
      return w[0][0].toUpperCase() + w.join(' ').slice(1) + '.' }).join(' '))
    setOut(ps.join('\n\n'))
  }
  return <><L t="Paragraphs (1-20)"><input type="number" min="1" max="20" value={n} onChange={e => setN(+e.target.value)} /></L><Err e={e} /><button className="on" onClick={gen}>Generate</button><button onClick={() => { setOut(''); setN(3); setE('') }}>Reset</button><Out value={out} name="lorem.txt" rows={10} /></>
}
