import { useEffect, useState } from 'react'
import { L, Err, Out } from '../ui.jsx'
const kb = n => n > 1048576 ? (n / 1048576).toFixed(2) + ' MB' : (n / 1024).toFixed(1) + ' KB'
const EXT = { 'image/png': 'png', 'image/jpeg': 'jpg', 'image/webp': 'webp' }
function useImg() {
  const [f, setF] = useState(null), [img, setImg] = useState(null), [err, setErr] = useState('')
  function pick(e) {
    const file = e.target.files[0]; setErr(''); setImg(null); setF(null); if (!file) return
    if (!file.type.startsWith('image/')) return setErr('Please choose an image file (PNG, JPG, WebP, GIF...).'); if (file.size > 25e6) return setErr('That file is larger than 25 MB.')
    const u = URL.createObjectURL(file), i = new Image(); i.onload = () => { setImg(i); setF(file) }; i.onerror = () => setErr('This image could not be read.'); i.src = u
  }
  return { f, img, err, pick }
}
export function ImgTool({ mode }) {
  const { f, img, err, pick } = useImg()
  const [o, setO] = useState({ w: '', h: '', lock: true, q: .8, fmt: mode === 'compress' ? 'image/webp' : 'image/png', x: 0, y: 0, cw: '', ch: '' }), [res, setRes] = useState(null), [e, setE] = useState(''), [b64, setB64] = useState('')
  const set = (k, v) => setO(p => ({ ...p, [k]: v })), nw = img?.naturalWidth, nh = img?.naturalHeight
  useEffect(() => {
    setRes(null); setE(''); setB64(''); if (!img) return
    setO(p => ({ ...p, w: nw, h: nh, cw: nw, ch: nh, x: 0, y: 0 }))
    if (mode === 'base64') { const r = new FileReader(); r.onload = () => setB64(r.result); r.readAsDataURL(f) }
  }, [img]) // eslint-disable-line
  function run() {
    setE(''); setRes(null); let W = nw, H = nh, sx = 0, sy = 0, sw = nw, sh = nh
    if (mode === 'resize') { W = Math.round(+o.w); H = Math.round(+o.h); if (!(W >= 1 && H >= 1 && W <= 10000 && H <= 10000)) return setE('Width and height must be between 1 and 10000 px.') }
    if (mode === 'crop') { sx = Math.round(+o.x); sy = Math.round(+o.y); sw = Math.round(+o.cw); sh = Math.round(+o.ch); if (!(sw >= 1 && sh >= 1 && sx >= 0 && sy >= 0 && sx + sw <= nw && sy + sh <= nh)) return setE(`The crop area must stay inside the image (${nw} x ${nh} px).`); W = sw; H = sh }
    const c = document.createElement('canvas'); c.width = W; c.height = H; const g = c.getContext('2d')
    if (o.fmt === 'image/jpeg') { g.fillStyle = '#fff'; g.fillRect(0, 0, W, H) }
    g.drawImage(img, sx, sy, sw, sh, 0, 0, W, H)
    c.toBlob(b => {
      if (!b) return setE('Could not create the image. Try a smaller size or another format.')
      if (b.type !== o.fmt) setE('Your browser cannot export ' + o.fmt + ', so ' + b.type + ' was used instead.')
      setRes({ b, url: URL.createObjectURL(b), W, H, name: f.name.replace(/\.[^.]+$/, '') + '-' + mode + '.' + (EXT[b.type] || 'png') })
    }, o.fmt, +o.q)
  }
  const fmtSel = list => <L t="Output format"><select value={o.fmt} onChange={ev => set('fmt', ev.target.value)}>{list.map(x => <option key={x} value={x}>{EXT[x].toUpperCase()}</option>)}</select></L>
  const chg = (k, v) => { if (mode === 'resize' && o.lock && v !== '') { if (k === 'w') return setO(p => ({ ...p, w: v, h: Math.round(v * nh / nw) })); if (k === 'h') return setO(p => ({ ...p, h: v, w: Math.round(v * nw / nh) })) } set(k, v) }
  const num = (k, t) => <L t={t}><input type="number" min="0" value={o[k]} onChange={ev => chg(k, ev.target.value)} /></L>
  return <><p className="mu">Your image is processed in this browser and is never uploaded.</p>
    <L t="Choose an image"><input type="file" accept="image/*" onChange={pick} /></L><Err e={err} />
    {img && <><p>{f.name}: {nw} x {nh} px, {kb(f.size)}</p>
      {mode === 'resize' && <><div className="two">{num('w', 'Width (px)')}{num('h', 'Height (px)')}</div><label><input type="checkbox" checked={o.lock} onChange={ev => set('lock', ev.target.checked)} />Keep aspect ratio</label>{fmtSel(['image/png', 'image/jpeg', 'image/webp'])}</>}
      {mode === 'compress' && <>{fmtSel(['image/webp', 'image/jpeg'])}<L t={'Quality: ' + Math.round(o.q * 100) + '%'}><input type="range" min=".1" max="1" step=".05" value={o.q} onChange={ev => set('q', ev.target.value)} /></L></>}
      {mode === 'convert' && fmtSel(['image/png', 'image/jpeg', 'image/webp'])}
      {mode === 'crop' && <><div className="two">{num('x', 'Left (x, px)')}{num('y', 'Top (y, px)')}{num('cw', 'Crop width (px)')}{num('ch', 'Crop height (px)')}</div>{fmtSel(['image/png', 'image/jpeg', 'image/webp'])}</>}
      {mode === 'base64' ? <>{b64 ? <><p>{b64.length.toLocaleString()} characters (Base64 is about 33% larger than the file).</p><Out value={b64} name="image-base64.txt" rows={6} /></> : <p>Reading file...</p>}</>
        : <><Err e={e} /><button className="on" onClick={run}>{mode === 'resize' ? 'Resize' : mode === 'compress' ? 'Compress' : mode === 'convert' ? 'Convert' : 'Crop'}</button></>}
    </>}
    {res && <div className="panel"><img className="pv" src={res.url} alt="Result preview" /><p role="status">{res.W} x {res.H} px, {kb(res.b.size)}{mode === 'compress' ? (res.b.size < f.size ? ` (${Math.round(100 - res.b.size / f.size * 100)}% smaller)` : ' (not smaller than the original; try lower quality)') : ''}</p><a className="btn" href={res.url} download={res.name}>Download</a></div>}</>
}
