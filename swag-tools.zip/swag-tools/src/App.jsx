import { useState } from 'react'
import { Routes, Route, Link } from 'react-router-dom'
import Home from './pages/Home.jsx'
import Tool from './pages/Tool.jsx'
import { Page } from './pages/Static.jsx'
import { usePrefs } from './store.jsx'
export default function App() {
  const { theme, setTheme } = usePrefs(), [open, setOpen] = useState(false)
  return <>
    <a className="skip" href="#main">Skip to content</a>
    <header className="hdr"><Link to="/" className="logo" onClick={() => setOpen(false)}>SWAG<b>Tools</b></Link>
      <button className="burger" aria-label="Menu" aria-expanded={open} onClick={() => setOpen(!open)}>☰</button>
      <nav className={open ? 'open' : ''} aria-label="Main" onClick={() => setOpen(false)}><Link to="/">All tools</Link><Link to="/page/about">About</Link><Link to="/page/contact">Contact</Link>
        <button onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')} aria-label={'Switch to ' + (theme === 'dark' ? 'light' : 'dark') + ' mode'}>{theme === 'dark' ? '☀ Light' : '🌙 Dark'}</button></nav></header>
    <main id="main"><Routes><Route path="/" element={<Home />} /><Route path="/tool/:slug" element={<Tool />} /><Route path="/page/:p" element={<Page />} /><Route path="*" element={<Page />} /></Routes></main>
    <footer className="ftr"><div className="wrap"><p><b>SWAG Tools</b>: free browser-based tools.</p>
      <p><Link to="/page/about">About Us</Link> · <Link to="/page/contact">Contact Us</Link> · <Link to="/page/privacy">Privacy Policy</Link> · <Link to="/page/terms">Terms of Use</Link> · <Link to="/page/disclaimer">Disclaimer</Link></p></div></footer></>
}
